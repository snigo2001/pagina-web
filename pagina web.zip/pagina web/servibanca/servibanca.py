from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('servibancaweb.html')

@app.route('/saludo/<nombre>')
def saludo(nombre):
    return f"<h1 style='text-align:center; color:#0078d4; margin-top:100px;'>¡Hola, {nombre}! Bienvenido a Servibanca 🏦</h1>"

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80, debug=False)